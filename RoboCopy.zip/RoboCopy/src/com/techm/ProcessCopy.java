package com.techm;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RoboCopy
 */
@WebServlet("/ProcessCopy")
public class ProcessCopy extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProcessCopy() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @throws IOException 
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException{
		String redirectMsg = "File Successfully uploaded. Please Execute forward.";
 		try {
			InputStream input = getServletContext().getResourceAsStream("/WEB-INF/RobocopyConfig.properties");
			if(input==null){
	            System.out.println("Sorry, unable to find properties file");
	            return;
			}
			Properties prop = new Properties();
			prop.load(input);
			String fileUploadPath = prop.getProperty("file.dat.uploadpath");
			String fileUploadName = prop.getProperty("file.dat.uploadFile");
			
			String[] sourceDir = request.getParameterValues("filterToCopy");
			String destDir = request.getParameter("destinationDirectory");
			String logDir = "";
			
			File file = new File(fileUploadPath);
			if(file.exists()){
				file.delete();
			} else {
				file.mkdirs();
			}
			PrintWriter writer = new PrintWriter(fileUploadPath+fileUploadName, "UTF-8");
			writer.println("@echo %time%");
			if(sourceDir != null && sourceDir.length > 0){
				for (int i = 0; i < sourceDir.length; i++) {
					logDir = request.getParameter("log");
					if(logDir == null || logDir.trim().length() == 0){
						logDir = "";
					} else {
						logDir = "/LOG:"+logDir;
 					}
					writer.println("robocopy "+sourceDir[i]+" "+destDir+" /MT:8 /mir "+logDir);
					logDir = "";
 				}
			}
 			writer.println("@echo %time%");
 			writer.close();
 			
		} catch (Exception e) {
 			e.printStackTrace();
 			redirectMsg = "Unable to generate bat file. Please check logs.";
		}  
 		response.sendRedirect("index.jsp?redirect=true&redirectMsg="+redirectMsg);
	}

}
