package com;

import java.util.Date;


public class OrderInfo {
	Integer orderId;
	Long orderAmount;
	String paymentStatus,orderNo,customerName,productName;
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}
	String deliveryStatus;
	Date orderDate;
	Date deliveryDate;
	String processType;
	@Override
	public String toString() {
		return "OrderInfo [orderId=" + orderId + ", orderAmount=" + orderAmount
				+ ", paymentStatus=" + paymentStatus + ", orderNo=" + orderNo
				+ ", customerName=" + customerName + ", productName="
				+ productName + ", deliveryStatus=" + deliveryStatus
				+ ", orderDate=" + orderDate + ", deliveryDate=" + deliveryDate
				+ ", processType=" + processType + ", processDesc="
				+ processDesc + "]";
	}
	String processDesc;
	public String getProcessType() {
		return processType;
	}
	public void setProcessType(String processType) {
		this.processType = processType;
	}
	public String getProcessDesc() {
		return processDesc;
	}
	public void setProcessDesc(String processDesc) {
		this.processDesc = processDesc;
	}
	public Integer getOrderId() {
		return orderId;
	}
	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}
	public Long getOrderAmount() {
		return orderAmount;
	}
	public void setOrderAmount(Long orderAmount) {
		this.orderAmount = orderAmount;
	}
	public String getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
	public String getDeliveryStatus() {
		return deliveryStatus;
	}
	public void setDeliveryStatus(String deliveryStatus) {
		this.deliveryStatus = deliveryStatus;
	}
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	public Date getDeliveryDate() {
		return deliveryDate;
	}
	public void setDeliveryDate(Date deliveryDate) {
		this.deliveryDate = deliveryDate;
	}
	
}
