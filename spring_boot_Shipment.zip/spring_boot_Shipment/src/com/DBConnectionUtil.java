package com;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnectionUtil {
	static Connection connection=getConnection();
	private static Connection getConnection()
	{
		try
		{
		if(null==connection)
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			return DriverManager.getConnection(  
					"jdbc:oracle:thin:@10.30.53.43:1521:xe","system","admin@123"); 
		}
		}
		catch(Exception e)
		{
			System.out.println("Exception  :"+e);
		}
		return connection;
	}
	public static Connection getConnectionCommon()
	{
		return connection;
	}
	
}
