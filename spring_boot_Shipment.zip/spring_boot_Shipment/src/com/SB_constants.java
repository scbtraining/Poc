package com;

public interface SB_constants {
	public static final String MSG_SUCCESS="Success";
	public static final String MSG_FAILED="Failed";
}
