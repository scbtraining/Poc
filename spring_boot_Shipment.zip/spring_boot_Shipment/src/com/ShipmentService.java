package com;

import java.util.List;

import com.CustomerInfo;

public interface ShipmentService {
	public String saveProduct(ProductInfo info);
	public String saveCustomer(CustomerInfo info);
	public String saveOrUpdateOrder(OrderInfo info);
	public List<OrderInfo> getOrderDetInfos();
	public String updatePaymentDetails(OrderInfo info);
	public List<OrderReportsInfo> viewRaports(Integer orderId);
}
