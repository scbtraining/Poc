package com;

import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/shipment")
public class ShipmentController {

	@Autowired
	private ShipmentService shipmentServiceImpl;
	@RequestMapping(value="/saveProduct",method=RequestMethod.POST,headers = "Accept=application/json")
	public ResponseEntity<String> saveProduct(@RequestBody ProductInfo productInfo)
	{
		String msg=shipmentServiceImpl.saveProduct(productInfo);
		return new ResponseEntity<String>(msg,HttpStatus.OK);
		
	}
	@RequestMapping(value="/saveCustomer",method=RequestMethod.POST,headers = "Accept=application/json")
	public ResponseEntity<String> saveProduct(@RequestBody CustomerInfo custInfo)
	{
		String msg=shipmentServiceImpl.saveCustomer(custInfo);
		return new ResponseEntity<String>(msg,HttpStatus.OK);
		
	}
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value="/getOrderDetails",method=RequestMethod.GET,headers = "Accept=application/json")
	public ResponseEntity<List<OrderInfo>> getOrderDetails()
	{
		List<OrderInfo> info=shipmentServiceImpl.getOrderDetInfos();
		
		return new ResponseEntity<List<OrderInfo>>(info,HttpStatus.OK);
	}
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value="/updateOrderDetails",method=RequestMethod.POST,headers = "Accept=application/json")
	public ResponseEntity<String> updateShipmentDetails(@RequestBody OrderInfo info)
	{
		System.out.println("info---"+info);
		String msg=shipmentServiceImpl.updatePaymentDetails(info);
		return new ResponseEntity<String>(msg,HttpStatus.OK);
	}
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value="/viewReportsByOrderId",method=RequestMethod.GET,headers = "Accept=application/json")
	public ResponseEntity<List<OrderReportsInfo>> viewReportByOrder(@RequestParam Integer orderId)
	{
		System.out.println("orderId---"+orderId);
		return new ResponseEntity<List<OrderReportsInfo>>(shipmentServiceImpl.viewRaports(orderId),HttpStatus.OK);
	}
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/hello", method = RequestMethod.GET)
	 public String hello() {
	  return "index";
	 }
}
