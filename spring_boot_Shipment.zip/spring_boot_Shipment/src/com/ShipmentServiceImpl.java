package com;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;


@Service("shipmentServiceImpl")
public class ShipmentServiceImpl implements ShipmentService
{
	@Override
	public String saveProduct(ProductInfo productInfo) {
		
		return null;
	}

	@Override
	public String saveCustomer(CustomerInfo custInfo) {
		return null;
	}

	@Override
	public String saveOrUpdateOrder(OrderInfo info) {
		return null;
	}

	@Override
	public List<OrderInfo> getOrderDetInfos() {
		Connection cn=null;
		List<OrderInfo> listorderInfos=new ArrayList<OrderInfo>();
		try
		{
			cn=DBConnectionUtil.getConnectionCommon();
			Statement st=cn.createStatement();
			String sql="select ORDERID,ORDERNO,ORDERDATE,TOTAL_AMOUNT,PAYMENT_STATUS,DELIVERY_STATUS,"
					+ "(SELECT CUSTOMERNAME FROM SB_CUSTOMER B WHERE B.CUSTOMERID=A.CUSTOMERID) CUSTOMER_NAME,"
					+ "(SELECT PRODUCTNAME FROM SB_PRODUCT C WHERE C.PRODUCTID =a.PRODUCTID ) productName "
					+ "from sb_ORDERDETAILS A order by ORDERID";
			System.out.println("sql---"+sql);
			ResultSet rs=st.executeQuery(sql);
			while(rs.next())
			{
				OrderInfo localinfo=new OrderInfo();
				localinfo.setOrderId(rs.getInt("ORDERID"));
				localinfo.setOrderNo(rs.getString("ORDERNO"));
				localinfo.setOrderDate(rs.getDate("ORDERDATE"));
				localinfo.setOrderAmount(rs.getLong("TOTAL_AMOUNT"));
				localinfo.setPaymentStatus(rs.getString("PAYMENT_STATUS"));
				localinfo.setDeliveryStatus(rs.getString("DELIVERY_STATUS"));
				localinfo.setCustomerName(rs.getString("CUSTOMER_NAME"));
				localinfo.setProductName(rs.getString("productName"));
				listorderInfos.add(localinfo);
			}
		}
		catch(Exception e)
		{
			System.out.println("Exception e---"+e);
		}
		return listorderInfos;
	}

	@Override
	public String updatePaymentDetails(OrderInfo info) {
		Connection cn=null;
		String msg="Successfully updated";
		PreparedStatement pre=null;
		try
		{
			cn=DBConnectionUtil.getConnectionCommon();
		
			pre=cn.prepareStatement("Update sb_ORDERDETAILS  set PAYMENT_STATUS=? , DELIVERY_STATUS=? where ORDERID=? ");
			if(info!=null)
			{
				pre.setString(1, info.getPaymentStatus());
				pre.setString(2, info.getDeliveryStatus());
				pre.setInt(3, info.getOrderId());
				boolean valid=pre.execute();
				System.out.println("valid---"+valid);
			}
			
		}
		catch(Exception e)
		{
			msg="error Occured :"+e; 
			System.out.println("Update order Details error occured :"+e);
		}
		
		
		updateShipmentReports(info);
		return msg;
	}
	private void updateShipmentReports(OrderInfo info)
	{
		Connection cn=null;
		String msg="Successfully updated";
		PreparedStatement pre=null;
		try
		{
			cn=DBConnectionUtil.getConnectionCommon();
		
			pre=cn.prepareStatement("insert into SB_SHIPMENTREPORTS values(?,?,?,?)");
			if(info!=null)
			{
				pre.setInt(1, info.getOrderId());
				pre.setDate(2, new java.sql.Date(new java.util.Date().getTime()) );
				pre.setString(3, info.getDeliveryStatus());
				pre.setString(4, info.getProcessDesc());
				boolean valid=pre.execute();
				System.out.println("valid---"+valid);
			}
			
		}
		catch(Exception e)
		{
			msg="error Occured :"+e; 
			System.out.println("Update report Details error occured :"+e);
		}
	}
	public List<OrderReportsInfo> viewRaports(Integer orderId)
	{
		Connection cn=null;
		List<OrderReportsInfo> orderReports=new ArrayList<OrderReportsInfo>();
		try
		{
			cn=DBConnectionUtil.getConnectionCommon();
			Statement st=cn.createStatement();
			String reportssql="select a.orderId,orderNo,processDate,processtype,process_desc from sb_ORDERDETAILS a, SB_SHIPMENTREPORTS b where a.orderId=b.orderId  and a.orderId="+orderId +" order by  a.orderId ,processDate";
			ResultSet rs=st.executeQuery(reportssql);
			while(rs.next())
			{
				OrderReportsInfo info=new OrderReportsInfo();
				info.setOrderId(rs.getInt("orderId"));
				info.setProcessDate(rs.getDate("processDate"));
				info.setProcessType(rs.getString("processtype"));
				info.setProcessDesc(rs.getString("process_desc"));
				orderReports.add(info);
			}
		}
		catch(Exception e)
		{
			System.out.println("Exception in getREports :"+e);
		}
		return orderReports;
	}
	
}
